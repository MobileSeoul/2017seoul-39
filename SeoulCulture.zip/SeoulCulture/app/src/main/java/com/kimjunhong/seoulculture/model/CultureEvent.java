package com.kimjunhong.seoulculture.model;

/**
 * Created by INMA on 2017. 7. 16..
 */

public class CultureEvent {
    int CULTCODE;
    int SUBJCODE;
    String CODENAME;
    String TITLE;
    String STRTDATE;
    String END_DATE;
    String TIME;
    String PLACE;
    String ORG_LINK;
    String MAIN_IMG;
    String HOMEPAGE;
    String USE_TRGT;
    String USE_FEE;
    String SPONSOR;
    String INQUIRY;
    String SUPPORT;
    String ETC_DESC;
    String AGELIMIT;
    String IS_FREE;
    String TICKET;
    String PROGRAM;
    String PLAYER;
    String CONTENTS;
    String GCODE;

    public int getCULTCODE() {
        return CULTCODE;
    }

    public int getSUBJCODE() {
        return SUBJCODE;
    }

    public String getCODENAME() {
        return CODENAME;
    }

    public String getTITLE() {
        return TITLE;
    }

    public String getSTRTDATE() {
        return STRTDATE;
    }

    public String getEND_DATE() {
        return END_DATE;
    }

    public String getTIME() {
        return TIME;
    }

    public String getPLACE() {
        return PLACE;
    }

    public String getORG_LINK() {
        return ORG_LINK;
    }

    public String getMAIN_IMG() {
        return MAIN_IMG;
    }

    public String getHOMEPAGE() {
        return HOMEPAGE;
    }

    public String getUSE_TRGT() {
        return USE_TRGT;
    }

    public String getUSE_FEE() {
        return USE_FEE;
    }

    public String getSPONSOR() {
        return SPONSOR;
    }

    public String getINQUIRY() {
        return INQUIRY;
    }

    public String getSUPPORT() {
        return SUPPORT;
    }

    public String getETC_DESC() {
        return ETC_DESC;
    }

    public String getAGELIMIT() {
        return AGELIMIT;
    }

    public String getIS_FREE() {
        return IS_FREE;
    }

    public String getTICKET() {
        return TICKET;
    }

    public String getPROGRAM() {
        return PROGRAM;
    }

    public String getPLAYER() {
        return PLAYER;
    }

    public String getCONTENTS() {
        return CONTENTS;
    }

    public String getGCODE() {
        return GCODE;
    }
}