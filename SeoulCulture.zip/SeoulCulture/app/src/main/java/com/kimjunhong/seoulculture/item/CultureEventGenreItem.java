package com.kimjunhong.seoulculture.item;

/**
 * Created by INMA on 2017. 8. 3..
 */

public class CultureEventGenreItem {
    String genre;

    public CultureEventGenreItem(String genre) {
        this.genre = genre;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
}
