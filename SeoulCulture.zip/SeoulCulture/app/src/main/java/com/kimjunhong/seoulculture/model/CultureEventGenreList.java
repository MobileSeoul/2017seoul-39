package com.kimjunhong.seoulculture.model;

/**
 * Created by INMA on 2017. 8. 3..
 */

public class CultureEventGenreList {
    int CODE;
    String CODENAME;

    public int getCODE() {
        return CODE;
    }

    public String getCODENAME() {
        return CODENAME;
    }
}
